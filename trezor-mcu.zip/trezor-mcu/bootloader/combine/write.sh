#!/bin/bash
st-flash write combined.bin 0x8000000
